<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SpotifyController;
use App\Http\Controllers\BookController;

Route::get('/callback', function () {
    return view('/api/callback');
});

Route::get('/callback', [SpotifyController::class, 'callback']);
Route::post('/search', [SpotifyController::class, 'search'])->name('search');


Route::get('/searchbook', [BookController::class, 'index']);
Route::post('/searchbook', [BookController::class, 'searchbook'])->name('searchbook');




