<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\GestioneController;
use App\Http\Controllers\InsegnamentiController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\IscrizioneController;


Route::get('/register', [RegisterController::class, 'showRegistrationForm']);
Route::post('/register', [RegisterController::class, 'register']);

Route::get('/login', [LoginController::class, 'showLoginForm']);
Route::post('/login', [LoginController::class, 'login']);
Route::get('/logout', [LoginController::class, 'logout']);


Route::get('/profile', [ProfileController::class, 'showProfile'])->name('profile');
Route::get('/profile/gestione', [ProfileController::class, 'editProfile'])->name('profile.gestione');
Route::get('/profile/logout', [ProfileController::class, 'logout'])->name('profile.logout');
Route::get('/profile/homeprofile', [ProfileController::class, 'Profile'])->name('profile.homeprofile');

Route::post('/iscrivi', [IscrizioneController::class, 'iscrizione'])->name('iscrivi');

Route::get('/gestione/agricoltura', [GestioneController::class, 'agricoltura'])->name('gestione.agricoltura');
Route::get('/gestione/chirurgia', [GestioneController::class, 'chirurgia'])->name('gestione.chirurgia');
Route::get('/gestione/economia', [GestioneController::class, 'economia'])->name('gestione.economia');
Route::get('/gestione/fisica', [GestioneController::class, 'fisica'])->name('gestione.fisica');
Route::get('/gestione/giurisprudenza', [GestioneController::class, 'giurisprudenza'])->name('gestione.giurisprudenza');
Route::get('/gestione/dicar', [GestioneController::class, 'dicar'])->name('gestione.dicar');
Route::get('/gestione/dieei', [GestioneController::class, 'dieei'])->name('gestione.dieei');
Route::get('/gestione/matematica', [GestioneController::class, 'matematica'])->name('gestione.matematica');
Route::get('/gestione/medicina', [GestioneController::class, 'medicina'])->name('gestione.medicina');
Route::get('/gestione/biologia', [GestioneController::class, 'biologia'])->name('gestione.biologia');
Route::get('/gestione/biomedica', [GestioneController::class, 'biomedica'])->name('gestione.biomedica');
Route::get('/gestione/chimica', [GestioneController::class, 'chimica'])->name('gestione.chimica');
Route::get('/gestione/farmacia', [GestioneController::class, 'farmacia'])->name('gestione.farmacia');
Route::get('/gestione/formazione', [GestioneController::class, 'formazione'])->name('gestione.formazione');
Route::get('/gestione/mediche', [GestioneController::class, 'mediche'])->name('gestione.mediche');
Route::get('/gestione/politica', [GestioneController::class, 'politica'])->name('gestione.politica');
Route::get('/gestione/umanistica', [GestioneController::class, 'umanistica'])->name('gestione.umanistica');
Route::get('/gestione/architettura', [GestioneController::class, 'architettura'])->name('gestione.architettura');
Route::get('/gestione/altascuola', [GestioneController::class, 'altascuola'])->name('gestione.altascuola');

Route::get('/gestione/agricoltura1', [GestioneController::class, 'agricoltura1'])->name('gestione.agricoltura1');
Route::get('/gestione/chirurgia1', [GestioneController::class, 'chirurgia1'])->name('gestione.chirurgia1');
Route::get('/gestione/economia1', [GestioneController::class, 'economia1'])->name('gestione.economia1');
Route::get('/gestione/fisica1', [GestioneController::class, 'fisica1'])->name('gestione.fisica1');
Route::get('/gestione/giurisprudenza1', [GestioneController::class, 'giurisprudenza1'])->name('gestione.giurisprudenza1');
Route::get('/gestione/dicar1', [GestioneController::class, 'dicar1'])->name('gestione.dicar1');
Route::get('/gestione/dieei1', [GestioneController::class, 'dieei1'])->name('gestione.dieei1');
Route::get('/gestione/matematica1', [GestioneController::class, 'matematica1'])->name('gestione.matematica1');
Route::get('/gestione/medicina1', [GestioneController::class, 'medicina1'])->name('gestione.medicina1');
Route::get('/gestione/biologia1', [GestioneController::class, 'biologia1'])->name('gestione.biologia1');
Route::get('/gestione/biomedica1', [GestioneController::class, 'biomedica1'])->name('gestione.biomedica1');
Route::get('/gestione/chimica1', [GestioneController::class, 'chimica1'])->name('gestione.chimica1');
Route::get('/gestione/farmacia1', [GestioneController::class, 'farmacia1'])->name('gestione.farmacia1');
Route::get('/gestione/formazione1', [GestioneController::class, 'formazione1'])->name('gestione.formazione1');
Route::get('/gestione/mediche1', [GestioneController::class, 'mediche1'])->name('gestione.mediche1');
Route::get('/gestione/politica1', [GestioneController::class, 'politica1'])->name('gestione.politica1');
Route::get('/gestione/umanistica1', [GestioneController::class, 'umanistica1'])->name('gestione.umanistica1');
Route::get('/gestione/architettura1', [GestioneController::class, 'architettura1'])->name('gestione.architettura1');
Route::get('/gestione/altascuola1', [GestioneController::class, 'altascuola1'])->name('gestione.altascuola1');

Route::get('/insegnamenti/agricoltura', [InsegnamentiController::class, 'agricoltura'])->name('insegnamenti.agricoltura');
Route::get('/insegnamenti/chirurgia', [InsegnamentiController::class, 'chirurgia'])->name('insegnamenti.chirurgia');
Route::get('/insegnamenti/economia', [InsegnamentiController::class, 'economia'])->name('insegnamenti.economia');
Route::get('/insegnamenti/fisica', [InsegnamentiController::class, 'fisica'])->name('insegnamenti.fisica');
Route::get('/insegnamenti/giurisprudenza', [InsegnamentiController::class, 'giurisprudenza'])->name('insegnamenti.giurisprudenza');
Route::get('/insegnamenti/dicar', [InsegnamentiController::class, 'dicar'])->name('insegnamenti.dicar');
Route::get('/insegnamenti/dieei', [InsegnamentiController::class, 'dieei'])->name('insegnamenti.dieei');
Route::get('/insegnamenti/matematica', [InsegnamentiController::class, 'matematica'])->name('insegnamenti.matematica');
Route::get('/insegnamenti/medicina', [InsegnamentiController::class, 'medicina'])->name('insegnamenti.medicina');
Route::get('/insegnamenti/biologia', [InsegnamentiController::class, 'biologia'])->name('insegnamenti.biologia');
Route::get('/insegnamenti/biomedica', [InsegnamentiController::class, 'biomedica'])->name('insegnamenti.biomedica');
Route::get('/insegnamenti/chimica', [InsegnamentiController::class, 'chimica'])->name('insegnamenti.chimica');
Route::get('/insegnamenti/farmacia', [InsegnamentiController::class, 'farmacia'])->name('insegnamenti.farmacia');
Route::get('/insegnamenti/formazione', [InsegnamentiController::class, 'formazione'])->name('insegnamenti.formazione');
Route::get('/insegnamenti/mediche', [InsegnamentiController::class, 'mediche'])->name('insegnamenti.mediche');
Route::get('/insegnamenti/politica', [InsegnamentiController::class, 'politica'])->name('insegnamenti.politica');
Route::get('/insegnamenti/umanistica', [InsegnamentiController::class, 'umanistica'])->name('insegnamenti.umanistica');
Route::get('/insegnamenti/architettura', [InsegnamentiController::class, 'architettura'])->name('insegnamenti.architettura');
Route::get('/insegnamenti/altascuola', [InsegnamentiController::class, 'altascuola'])->name('insegnamenti.altascuola');

Route::get('/insegnamenti/agricoltura1', [InsegnamentiController::class, 'agricoltura1'])->name('insegnamenti.agricoltura1');
Route::get('/insegnamenti/agricoltura2', [InsegnamentiController::class, 'agricoltura2'])->name('insegnamenti.agricoltura2');
Route::get('/insegnamenti/agricoltura3', [InsegnamentiController::class, 'agricoltura3'])->name('insegnamenti.agricoltura3');
Route::get('/insegnamenti/agricoltura4', [InsegnamentiController::class, 'agricoltura4'])->name('insegnamenti.agricoltura4');
Route::get('/insegnamenti/agricoltura5', [InsegnamentiController::class, 'agricoltura5'])->name('insegnamenti.agricoltura5');
Route::get('/insegnamenti/agricoltura6', [InsegnamentiController::class, 'agricoltura6'])->name('insegnamenti.agricoltura6');
Route::get('/insegnamenti/agricoltura7', [InsegnamentiController::class, 'agricoltura7'])->name('insegnamenti.agricoltura7');
Route::get('/insegnamenti/agricoltura8', [InsegnamentiController::class, 'agricoltura8'])->name('insegnamenti.agricoltura8');

Route::get('/insegnamenti/chirurgia1', [InsegnamentiController::class, 'chirurgia1'])->name('insegnamenti.chirurgia1');
Route::get('/insegnamenti/chirurgia2', [InsegnamentiController::class, 'chirurgia2'])->name('insegnamenti.chirurgia2');
Route::get('/insegnamenti/chirurgia3', [InsegnamentiController::class, 'chirurgia3'])->name('insegnamenti.chirurgia3');
Route::get('/insegnamenti/chirurgia4', [InsegnamentiController::class, 'chirurgia4'])->name('insegnamenti.chirurgia4');
Route::get('/insegnamenti/chirurgia5', [InsegnamentiController::class, 'chirurgia5'])->name('insegnamenti.chirurgia5');


Route::get('/insegnamenti/economia1', [InsegnamentiController::class, 'economia1'])->name('insegnamenti.economia1');
Route::get('/insegnamenti/economia2', [InsegnamentiController::class, 'economia2'])->name('insegnamenti.economia2');
Route::get('/insegnamenti/economia3', [InsegnamentiController::class, 'economia3'])->name('insegnamenti.economia3');
Route::get('/insegnamenti/economia4', [InsegnamentiController::class, 'economia4'])->name('insegnamenti.economia4');
Route::get('/insegnamenti/economia5', [InsegnamentiController::class, 'economia5'])->name('insegnamenti.economia5');
Route::get('/insegnamenti/economia6', [InsegnamentiController::class, 'economia6'])->name('insegnamenti.economia6');
Route::get('/insegnamenti/economia7', [InsegnamentiController::class, 'economia7'])->name('insegnamenti.economia7');

Route::get('/insegnamenti/fisica1', [InsegnamentiController::class, 'fisica1'])->name('insegnamenti.fisica1');
Route::get('/insegnamenti/fisica2', [InsegnamentiController::class, 'fisica2'])->name('insegnamenti.fisica2');

Route::get('/insegnamenti/giurisprudenza1', [InsegnamentiController::class, 'giurisprudenza1'])->name('insegnamenti.giurisprudenza1');

Route::get('/insegnamenti/dicar1', [InsegnamentiController::class, 'dicar1'])->name('insegnamenti.dicar1');
Route::get('/insegnamenti/dicar2', [InsegnamentiController::class, 'dicar2'])->name('insegnamenti.dicar2');
Route::get('/insegnamenti/dicar3', [InsegnamentiController::class, 'dicar3'])->name('insegnamenti.dicar3');
Route::get('/insegnamenti/dicar4', [InsegnamentiController::class, 'dicar4'])->name('insegnamenti.dicar4');
Route::get('/insegnamenti/dicar5', [InsegnamentiController::class, 'dicar5'])->name('insegnamenti.dicar5');
Route::get('/insegnamenti/dicar6', [InsegnamentiController::class, 'dicar6'])->name('insegnamenti.dicar6');
Route::get('/insegnamenti/dicar7', [InsegnamentiController::class, 'dicar7'])->name('insegnamenti.dicar7');
Route::get('/insegnamenti/dicar8', [InsegnamentiController::class, 'dicar8'])->name('insegnamenti.dicar8');

Route::get('/insegnamenti/dieei1', [InsegnamentiController::class, 'dieei1'])->name('insegnamenti.dieei1');
Route::get('/insegnamenti/dieei2', [InsegnamentiController::class, 'dieei2'])->name('insegnamenti.dieei2');
Route::get('/insegnamenti/dieei3', [InsegnamentiController::class, 'dieei3'])->name('insegnamenti.dieei3');
Route::get('/insegnamenti/dieei4', [InsegnamentiController::class, 'dieei4'])->name('insegnamenti.dieei4');
Route::get('/insegnamenti/dieei5', [InsegnamentiController::class, 'dieei5'])->name('insegnamenti.dieei5');
Route::get('/insegnamenti/dieei6', [InsegnamentiController::class, 'dieei6'])->name('insegnamenti.dieei6');
Route::get('/insegnamenti/dieei7', [InsegnamentiController::class, 'dieei7'])->name('insegnamenti.dieei7');
Route::get('/insegnamenti/dieei8', [InsegnamentiController::class, 'dieei8'])->name('insegnamenti.dieei8');

Route::get('/insegnamenti/matematica1', [InsegnamentiController::class, 'matematica1'])->name('insegnamenti.matematica1');
Route::get('/insegnamenti/matematica2', [InsegnamentiController::class, 'matematica2'])->name('insegnamenti.matematica2');
Route::get('/insegnamenti/matematica3', [InsegnamentiController::class, 'matematica3'])->name('insegnamenti.matematica3');
Route::get('/insegnamenti/matematica4', [InsegnamentiController::class, 'matematica4'])->name('insegnamenti.matematica4');

Route::get('/insegnamenti/medicina1', [InsegnamentiController::class, 'medicina1'])->name('insegnamenti.medicina1');
Route::get('/insegnamenti/medicina2', [InsegnamentiController::class, 'medicina2'])->name('insegnamenti.medicina2');
Route::get('/insegnamenti/medicina3', [InsegnamentiController::class, 'medicina3'])->name('insegnamenti.medicina3');
Route::get('/insegnamenti/medicina4', [InsegnamentiController::class, 'medicina4'])->name('insegnamenti.medicina4');
Route::get('/insegnamenti/medicina5', [InsegnamentiController::class, 'medicina5'])->name('insegnamenti.medicina5');

Route::get('/insegnamenti/biologia1', [InsegnamentiController::class, 'biologia1'])->name('insegnamenti.biologia1');
Route::get('/insegnamenti/biologia2', [InsegnamentiController::class, 'biologia2'])->name('insegnamenti.biologia2');
Route::get('/insegnamenti/biologia3', [InsegnamentiController::class, 'biologia3'])->name('insegnamenti.biologia3');
Route::get('/insegnamenti/biologia4', [InsegnamentiController::class, 'biologia4'])->name('insegnamenti.biologia4');
Route::get('/insegnamenti/biologia5', [InsegnamentiController::class, 'biologia5'])->name('insegnamenti.biologia5');
Route::get('/insegnamenti/biologia6', [InsegnamentiController::class, 'biologia6'])->name('insegnamenti.biologia6');
Route::get('/insegnamenti/biologia7', [InsegnamentiController::class, 'biologia7'])->name('insegnamenti.biologia7');
Route::get('/insegnamenti/biologia8', [InsegnamentiController::class, 'biologia8'])->name('insegnamenti.biologia8');
Route::get('/insegnamenti/biologia9', [InsegnamentiController::class, 'biologia9'])->name('insegnamenti.biologia9');
Route::get('/insegnamenti/biologia10', [InsegnamentiController::class, 'biologia10'])->name('insegnamenti.biologia10');

Route::get('/insegnamenti/biomedica1', [InsegnamentiController::class, 'biomedica1'])->name('insegnamenti.biomedica1');
Route::get('/insegnamenti/biomedica2', [InsegnamentiController::class, 'biomedica2'])->name('insegnamenti.biomedica2');
Route::get('/insegnamenti/biomedica3', [InsegnamentiController::class, 'biomedica3'])->name('insegnamenti.biomedica3');
Route::get('/insegnamenti/biomedica4', [InsegnamentiController::class, 'biomedica4'])->name('insegnamenti.biomedica4');
Route::get('/insegnamenti/biomedica5', [InsegnamentiController::class, 'biomedica5'])->name('insegnamenti.biomedica5');
Route::get('/insegnamenti/biomedica6', [InsegnamentiController::class, 'biomedica6'])->name('insegnamenti.biomedica6');
Route::get('/insegnamenti/biomedica7', [InsegnamentiController::class, 'biomedica7'])->name('insegnamenti.biomedica7');
Route::get('/insegnamenti/biomedica8', [InsegnamentiController::class, 'biomedica8'])->name('insegnamenti.biomedica8');

Route::get('/insegnamenti/chimica1', [InsegnamentiController::class, 'chimica1'])->name('insegnamenti.chimica1');
Route::get('/insegnamenti/chimica2', [InsegnamentiController::class, 'chimica2'])->name('insegnamenti.chimica2');
Route::get('/insegnamenti/chimica3', [InsegnamentiController::class, 'chimica3'])->name('insegnamenti.chimica3');

Route::get('/insegnamenti/farmacia1', [InsegnamentiController::class, 'farmacia1'])->name('insegnamenti.farmacia1');
Route::get('/insegnamenti/farmacia2', [InsegnamentiController::class, 'farmacia2'])->name('insegnamenti.farmacia2');
Route::get('/insegnamenti/farmacia3', [InsegnamentiController::class, 'farmacia3'])->name('insegnamenti.farmacia3');

Route::get('/insegnamenti/formazione1', [InsegnamentiController::class, 'formazione1'])->name('insegnamenti.formazione1');
Route::get('/insegnamenti/formazione2', [InsegnamentiController::class, 'formazione2'])->name('insegnamenti.formazione2');
Route::get('/insegnamenti/formazione3', [InsegnamentiController::class, 'formazione3'])->name('insegnamenti.formazione3');
Route::get('/insegnamenti/formazione4', [InsegnamentiController::class, 'formazione4'])->name('insegnamenti.formazione4');
Route::get('/insegnamenti/formazione5', [InsegnamentiController::class, 'formazione5'])->name('insegnamenti.formazione5');

Route::get('/insegnamenti/mediche1', [InsegnamentiController::class, 'mediche1'])->name('insegnamenti.mediche1');
Route::get('/insegnamenti/mediche2', [InsegnamentiController::class, 'mediche2'])->name('insegnamenti.mediche2');
Route::get('/insegnamenti/mediche3', [InsegnamentiController::class, 'mediche3'])->name('insegnamenti.mediche3');
Route::get('/insegnamenti/mediche4', [InsegnamentiController::class, 'mediche4'])->name('insegnamenti.mediche4');
Route::get('/insegnamenti/mediche5', [InsegnamentiController::class, 'mediche5'])->name('insegnamenti.mediche5');

Route::get('/insegnamenti/politica1', [InsegnamentiController::class, 'politica1'])->name('insegnamenti.politica1');

Route::get('/insegnamenti/umanistica1', [InsegnamentiController::class, 'umanistica1'])->name('insegnamenti.umanistica1');

Route::get('/insegnamenti/architettura1', [InsegnamentiController::class, 'architettura1'])->name('insegnamenti.architettura1');

Route::get('/insegnamenti/altascuola1', [InsegnamentiController::class, 'altascuola1'])->name('insegnamenti.altascuola1');

// Homepage route
Route::get('/', function () {
    return view('welcome');
});

// Authentication routes
Auth::routes();

// Routes that require authentication
Route::middleware(['auth'])->group(function () {
    Route::get('home', [IscrizioneController::class, 'showHome'])->name('home');
    Route::post('iscrizione', [IscrizioneController::class, 'iscrizione'])->name('iscrizione');
    Route::get('/home', [LoginController::class, 'home']);

    Route::get('/home', [ProfileController::class, 'showProfile'])->name('home');
    Route::get('/profile/gestione', [ProfileController::class, 'editProfile'])->name('profile.gestione');
    Route::get('/profile/logout', [ProfileController::class, 'logout'])->name('profile.logout');
    Route::post('/profile/homeprofile', [ProfileController::class, 'updateProfile'])->name('profile.homeprofile');

    Route::get('/gestione/agricoltura', [GestioneController::class, 'agricoltura'])->name('gestione.agricoltura');
    Route::get('/gestione/chirurgia', [GestioneController::class, 'chirurgia'])->name('gestione.chirurgia');
    Route::get('/gestione/economia', [GestioneController::class, 'economia'])->name('gestione.economia');
    Route::get('/gestione/fisica', [GestioneController::class, 'fisica'])->name('gestione.fisica');
    Route::get('/gestione/giurisprudenza', [GestioneController::class, 'giurisprudenza'])->name('gestione.giurisprudenza');
    Route::get('/gestione/dicar', [GestioneController::class, 'dicar'])->name('gestione.dicar');
    Route::get('/gestione/dieei', [GestioneController::class, 'dieei'])->name('gestione.dieei');
    Route::get('/gestione/matematica', [GestioneController::class, 'matematica'])->name('gestione.matematica');
    Route::get('/gestione/medicina', [GestioneController::class, 'medicina'])->name('gestione.medicina');
    Route::get('/gestione/biologia', [GestioneController::class, 'biologia'])->name('gestione.biologia');
    Route::get('/gestione/biomedica', [GestioneController::class, 'biomedica'])->name('gestione.biomedica');
    Route::get('/gestione/chimica', [GestioneController::class, 'chimica'])->name('gestione.chimica');
    Route::get('/gestione/farmacia', [GestioneController::class, 'farmacia'])->name('gestione.farmacia');
    Route::get('/gestione/formazione', [GestioneController::class, 'formazione'])->name('gestione.formazione');
    Route::get('/gestione/mediche', [GestioneController::class, 'mediche'])->name('gestione.mediche');
    Route::get('/gestione/politica', [GestioneController::class, 'politica'])->name('gestione.politica');
    Route::get('/gestione/umanistica', [GestioneController::class, 'umanistica'])->name('gestione.umanistica');
    Route::get('/gestione/architettura', [GestioneController::class, 'architettura'])->name('gestione.architettura');
    Route::get('/gestione/altascuola', [GestioneController::class, 'altascuola'])->name('gestione.altascuola');

    Route::get('/gestione/agricoltura1', [GestioneController::class, 'agricoltura1'])->name('gestione.agricoltura1');
    Route::get('/gestione/chirurgia1', [GestioneController::class, 'chirurgia1'])->name('gestione.chirurgia1');
    Route::get('/gestione/economia1', [GestioneController::class, 'economia1'])->name('gestione.economia1');
    Route::get('/gestione/fisica1', [GestioneController::class, 'fisica1'])->name('gestione.fisica1');
    Route::get('/gestione/giurisprudenza1', [GestioneController::class, 'giurisprudenza1'])->name('gestione.giurisprudenza1');
    Route::get('/gestione/dicar1', [GestioneController::class, 'dicar1'])->name('gestione.dicar1');
    Route::get('/gestione/dieei1', [GestioneController::class, 'dieei1'])->name('gestione.dieei1');
    Route::get('/gestione/matematica1', [GestioneController::class, 'matematica1'])->name('gestione.matematica1');
    Route::get('/gestione/medicina1', [GestioneController::class, 'medicina1'])->name('gestione.medicina1');
    Route::get('/gestione/biologia1', [GestioneController::class, 'biologia1'])->name('gestione.biologia1');
    Route::get('/gestione/biomedica1', [GestioneController::class, 'biomedica1'])->name('gestione.biomedica1');
    Route::get('/gestione/chimica1', [GestioneController::class, 'chimica1'])->name('gestione.chimica1');
    Route::get('/gestione/farmacia1', [GestioneController::class, 'farmacia1'])->name('gestione.farmacia1');
    Route::get('/gestione/formazione1', [GestioneController::class, 'formazione1'])->name('gestione.formazione1');
    Route::get('/gestione/mediche1', [GestioneController::class, 'mediche1'])->name('gestione.mediche1');
    Route::get('/gestione/politica1', [GestioneController::class, 'politica1'])->name('gestione.politica1');
    Route::get('/gestione/umanistica1', [GestioneController::class, 'umanistica1'])->name('gestione.umanistica1');
    Route::get('/gestione/architettura1', [GestioneController::class, 'architettura1'])->name('gestione.architettura1');
    Route::get('/gestione/altascuola1', [GestioneController::class, 'altascuola1'])->name('gestione.altascuola1');
});

?>


