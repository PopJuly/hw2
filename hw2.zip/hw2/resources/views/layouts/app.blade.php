<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('css/hw2.css') }}">
    <script src="css/mappa.js" defer></script>
    <script src="css/hw2.js" defer></script>
 </head>

<body>
    <nav></nav>
    <div class='red'></div>

    <div class="container_foto">
        <img class='studium' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_1.png" />  
        <img class='studenti' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_2.jpg" />
    </div>

    

    <div class="container_content">
        @yield('content')
    </div>



   </body>
</html>
