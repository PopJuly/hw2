
<!DOCTYPE html>
<html>
<head>
    <title>Profilo</title>
    <link rel="stylesheet" href="{{ asset('css/gestione.css') }}">
</head>
<body>

    <nav></nav>
    <div class='red'></div>

    <div class="container_foto">
        <img class='studium' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_1.png" />  
        <img class='studenti' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_2.jpg" />
    </div>


    <article>
        
    <div class="container">
        @yield('content')
    </div>

</article>

</body>
</html>
