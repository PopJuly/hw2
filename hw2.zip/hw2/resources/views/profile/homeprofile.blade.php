@extends('layouts.profiler')

@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>Profilo</title>
</head>
<body>
    <article>
        <section>

        <br><p><strong>Profilo di {{ Auth::user()->name }}</strong></p><h1></h1><br>
          <ol class='utente'>
          <p class='dip3'><font>&#9654</font><a href="{{ route('profile.gestione') }}">Gestione degli insegnamenti</a></p>
          <p class='dip3'><font>&#9654</font><a href="/logout">Logout</a></p><br>
          </ol><br>

          <div class='container2'>
          <ul>
        <p><strong>INSEGNAMENTI</strong></p><br>
        @foreach ($iscrizioni as $iscrizione)
            <li><p class='insegnamenti'>{{ $iscrizione->insegnamento->title }}</p></li><br>
        @endforeach
    </ul></div>
    <br>

       </section>
        
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
    
</article>
</body>
</html>
@endsection
