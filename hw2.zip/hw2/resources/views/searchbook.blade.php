@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>Open Library Author Search</title>
</head>
<body>
    <article>
        
    <section>
    <br><p><strong>RICERCA SU OPEN LIBRARY</strong></p><h1></h1><br>
          <ol class='utente'><br><br>
          <p class='dip3'><font>&#9654</font><a href="/">Torna alla homepage</a></p><br>
          </ol>

    <form action="{{ route('searchbook') }}" method="POST">
        @csrf
        <input type="text" name="author" placeholder="Inserire il nome dell'autore" value="{{ old('author', $author ?? '') }}" required><br>
        <button type="submit">Search</button>
    </form>
<div class='container2'>
    @if (isset($books) && count($books) > 0)
        <ul>
            @foreach ($books as $book)
                <div>
                   <strong>{{ $book['title'] }} ({{ $book['first_publish_year'] ?? 'Unknown Year' }})</strong>
                    @if (isset($book['cover_i']))
                        <div>
                            <img src="https://covers.openlibrary.org/b/id/{{ $book['cover_i'] }}-M.jpg" />
                        </div><br>
                    @endif
                    </div>
            @endforeach
        </ul>
    @elseif (isset($author))
        <p class='black'>No books found for author "{{ $author }}".</p>
    @endif
</div>
</section>

<footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
</article>
</body>
</html>
@endsection
