@extends('layouts.profiler')

@section('content')
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="{{ url('/home') }}">Home</a>
          <a class='barra_controllo' href="{{ route('profile.homeprofile') }}">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Automation Engineering and Control of Complex Systems</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Communication Engineering LM-27</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Electrical Engineering for Sustainable Green Energy Transition LM-28</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Electronic Engineering LM-29</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Ingegneria elettronica L-8</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Ingegneria industriale L-9</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Ingegneria informatica L-8</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.dieei1') }}">Ingegneria informatica LM-32</li></a><br>

            <a class='insegnamenti' href="{{ route('profile.gestione') }}">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
@endsection