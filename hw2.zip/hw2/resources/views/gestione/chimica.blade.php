@extends('layouts.profiler')

@section('content')
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="{{ url('/home') }}">Home</a>
          <a class='barra_controllo' href="{{ route('profile.homeprofile') }}">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class='insegnamenti' href="{{ route('gestione.chimica1') }}">Chimica Industriale L-27</a></li>
            <li><a class='insegnamenti' href="{{ route('gestione.chimica1') }}">Chimica L-27</a></li>
            <li><a class='insegnamenti' href="{{ route('gestione.chimica1') }}">Scienze chimiche LM-54</a></li>
            <br>

            <a class='insegnamenti' href="{{ route('profile.gestione') }}">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
@endsection