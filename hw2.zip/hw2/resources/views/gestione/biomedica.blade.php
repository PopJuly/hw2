@extends('layouts.profiler')

@section('content')
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="{{ url('/home') }}">Home</a>
          <a class='barra_controllo' href="{{ route('profile.homeprofile') }}">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Biotecnologie L-2<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Biotecnologie Mediche LM-9<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Fisioterapia (abilitante alla professione sanitaria di Fisioterapista) L/SNT2<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Ortottica ed assistenza oftalmologica<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Scienze della Nutrizione Umana LM-61<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Scienze e tecniche delle attività motorie preventive e adattate LM-67<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Scienze motorie L-22<br></li></a>
            <li><a class='insegnamenti' href="{{ route('gestione.biomedica1') }}">Terapia occupazionale (abilitante alla professione sanitaria di Terapista occupazionale) L/SNT2<br></li></a>
            <br>

            <a class='insegnamenti' href="{{ route('profile.gestione') }}">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
@endsection