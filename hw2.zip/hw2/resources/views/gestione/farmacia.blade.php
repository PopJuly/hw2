@extends('layouts.profiler')

@section('content')
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="{{ url('/home') }}">Home</a>
          <a class='barra_controllo' href="{{ route('profile.homeprofile') }}">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="{{ route('gestione.farmacia1') }}">Chimica e tecnologia farmaucetiche LM-13</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.farmacia1') }}">Farmacia LM-13</li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.farmacia1') }}">Scienze farmaucetiche applicate L-29</li></a>
            <br>

            <a class='insegnamenti' href="{{ route('profile.gestione') }}">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
@endsection