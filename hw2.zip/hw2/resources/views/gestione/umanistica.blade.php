@extends('layouts.profiler')

@section('content')
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="{{ url('/home') }}">Home</a>
          <a class='barra_controllo' href="{{ route('profile.homeprofile') }}">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Beni Culturali - Siracusa L-1<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Beni culturali L-1<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Cattedra Jean MONNET - Politica e comunicazione nella sfera pubblica europea L-5<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Comunicazione della cultura e dello spettacolo LM-65<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Filologia classica LM-15<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Filologia moderna LM-14<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Filosofia L-5<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Lettere L-10<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Letterato arabo<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Letterato inglese<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Letterato russo<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Letterato spagnolo<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Letterato tedesco<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Lingue e culture europee, euroamericane ed orientali L-11<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Lingue e letterature comparate LM-37<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Lingue per la cooperazione internazionale LM-38<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Matricole - Recupero OFA<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Mediazione linguistica e interculturale L-12<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Prenotazioni esami scritti corsi di lingua<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Scienze del testo per le professioni digitali LM-43<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Scienze e lingue per la comunicazione L-20<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Scienze filosofiche<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Scienze Linguistiche per l'intercultura e la formazione LM-39<br></li></a>
            <li><a class="insegnamenti" href="{{ route('gestione.umanistica1') }}">Storia dell'arte e beni culturali LM-89<br></li></a>
            <br>

            <a class='insegnamenti' href="{{ route('profile.gestione') }}">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
@endsection