@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>Spotify Album Search</title>
</head>
<body>
<article>
<section>
          <br><p><strong>RICERCA SU SPOTIFY</strong></p><h1></h1><br>
          <ol><br><br>
          <p class='dip3'><font>&#9654</font><a href="/">Torna alla homepage</a></p><br>
          </ol>

          <form action="{{ route('search') }}" method="POST">
        @csrf
        <input type="text" name="query" placeholder="Nome dell'album" required>
        <button type="submit">Search</button>
    </form>
          

    @if (isset($album))
     <section id="music-view">    
        <p class='black'><strong>Name:</strong><br>{{ $album['name'] }}</p>
        <p class='black'><strong>Artist:</strong> {{ $album['artists'][0]['name'] }}</p>
        <img id='music-view' src="{{ $album['images'][0]['url'] }}"><br>
     </section>

        @elseif (isset($error))
        <p>{{ $error }}</p>
    @endif

        <br>
       </section>
        
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
    </article>
    
</body>
</html>
@endsection
