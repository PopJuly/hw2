@extends('layouts.app')


@section('content')
<html>
  <body>
    <article>
<section>
             
    <br><p><strong>ANNO ACCADEMICO </strong> <h1></h1>

    <select name='anno_accademico'>
      <option value = '2023-24'>2023/2024</option>
      <option value = '2022-23'>2022/2023</option>
      <option value = '2021-22'>2021/2022</option>
      <option value = '2020-21'>2020/2021</option>
      <option value = '2019-20'>2019/2020</option>
      <option value = '2018-19'>2018/2019</option>
      <option value = '2017-18'>2017/2018</option>
      <option value = '2016-17'>2016/2017</option>
      <option value = '2015-16'>2015/2016</option>
      <option value = '2014-15'>2014/2015</option>
    </select>

    <div class="boxdipartimenti2">
      <strong><div id="dipartimenti">ECONOMIA AZIENDALE L-18</strong></div><h1 class="dipartimenti"></h1>
      <em>INSEGNAMENTI</em><br>
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=30078804-5989-4395-B169-9C7D09957EAD/'><font>&#9654</font>CONTABILITA' E BILANCIO (A - L) - Curriculum unico - Anno: 2 - Primo semestre<br></p></a>
      1014492 - RIZZA CARMELA
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=DF904D5F-25D1-4D4C-B60C-E66D6E9B126E/'><font>&#9654</font>CONTABILITA' E BILANCIO (M - Z) - Curriculum unico - Anno: 2 - Primo semestre<br></p></a>
      1014492 - FRISENNA CLAUDIA
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=B648CBD4-D017-48D7-B7C1-CD5AA0ACB665/'><font>&#9654</font>DIRITTO COMMERCIALE (A - L) - Curriculum unico - Anno: 2 - Primo semestre<br></p></a>
      1000063 - SANFILIPPO PIERPAOLO MICHELE
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=1AB7B87C-32C7-4894-963E-9DC7F4B31AFC/'><font>&#9654</font>DIRITTO COMMERCIALE (M - Z) - Curriculum unico - Anno: 2 - Primo semestre<br></p></a>
      1000063 - MACRI' ENRICO
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=9CCA755F-CDBB-4A35-8B61-B822C66FEA52/'><font>&#9654</font>DIRITTO TRIBUTARIO (A - L) - Curriculum unico - Anno: 3 - Primo semestre<br></p></a>
      1000096 - GUIDARA ANTONIO
      <br><p class="dip2"><a class="dip2" href='https://syllabus.unict.it/insegnamento.php?mod=20276AF5-F3DE-4F52-928F-A494C7540EA3/'><font>&#9654</font>DIRITTO TRIBUTARIO (M - Z) - Curriculum unico - Anno: 3 - Primo semestre<br></p></a>
      1000096 - SALANITRO GUIDO
 
      <br><br>
    

    </div><br>
     
   
    <p><strong>IN EVIDENZA</strong><h1></h1><br><br>
    <ol>  
    <p class='dip3'>
      <font>&#9654</font>
    <a href='https://studium.unict.it/dokeos/tutorial_teams_integration.pdf'>Collegamento insegnamenti con Teams </a></p> <br><br>
     <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti_17-18.pdf'>Attivazione insegnamenti </a></p><br> <p class='dip3'><font>&#9654</font>
      <a href='https://www.unict.it/'>Portale UniCT </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Portale Studenti </a></p><br> <p class='dip3'><font>&#9654</font> 
     <a href='http://www.dieei.unict.it'>Portale Docenti</a></p><br>
    <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial Studenti </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial Docenti </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial export e import materiale didattico </a></p><br><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial prenotazioni </a></p><br></ol>
<span class="login"><strong>LOGIN STUDENTI</strong><br>il login degli studenti deve avvenire con le credenziali (Codice Fiscale e password) del nuovo portale studenti Smart_edu. Se non è stata impostata una password, fare accesso al portale studenti con SPID o CIE e impostarla tramite le impostazioni.</span><br>
<p><strong>APP MOBILE </strong> <h1></h1>
<a><img class='googleplay' src="https://en.logodownload.org/wp-content/uploads/2019/06/get-it-on-google-play-badge.png" /></a><br>
<a><img class='appstore' src="https://logos-download.com/wp-content/uploads/2016/06/Download_on_the_App_Store_logo.png" /></a><br><br><br><br>
</p>
     </section>
    <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
      <div class='redfooter'></div>
    </footer>
      </article> 
    
  </body>
</html>
@endsection
