@extends('layouts.app')


@section('content')
<html>
  <body>
    <article>
<section>
             
    <br><p><strong>ANNO ACCADEMICO </strong> <h1></h1>

    <select name='anno_accademico'>
      <option value = '2023-24'>2023/2024</option>
      <option value = '2022-23'>2022/2023</option>
      <option value = '2021-22'>2021/2022</option>
      <option value = '2020-21'>2020/2021</option>
      <option value = '2019-20'>2019/2020</option>
      <option value = '2018-19'>2018/2019</option>
      <option value = '2017-18'>2017/2018</option>
      <option value = '2016-17'>2016/2017</option>
      <option value = '2015-16'>2015/2016</option>
      <option value = '2014-15'>2014/2015</option>
    </select>

    <div class="boxdipartimenti2">
      <strong><div id="dipartimenti">ARCHITETTURA</strong></div><h1 class="dipartimenti"></h1>
      <em>INSEGNAMENTI</em><br>
      <br><p class="dip2"><a class="dip2" href=' '><font>&#9654</font>LABORATORIO DI PROGETTAZIONE URBANISTICA (M - Z)<br></p></a>
      1016435 - BARBAROSSA LUCA
      
      <br><br>
     
 
     </div><br>
     
   
    <p><strong>IN EVIDENZA</strong><h1></h1><br><br>
    <ol>  
    <p class='dip3'>
      <font>&#9654</font>
    <a href='https://studium.unict.it/dokeos/tutorial_teams_integration.pdf'>Collegamento insegnamenti con Teams </a></p> <br><br>
     <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti_17-18.pdf'>Attivazione insegnamenti </a></p><br> <p class='dip3'><font>&#9654</font>
      <a href='https://www.unict.it/'>Portale UniCT </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Portale Studenti </a></p><br> <p class='dip3'><font>&#9654</font> 
     <a href='http://www.dieei.unict.it'>Portale Docenti</a></p><br>
    <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial Studenti </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial Docenti </a></p><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial export e import materiale didattico </a></p><br><br>
     <p class='dip3'><font>&#9654</font> <a href='http://www.dieei.unict.it'>Tutorial prenotazioni </a></p><br></ol>
<span class="login"><strong>LOGIN STUDENTI</strong><br>il login degli studenti deve avvenire con le credenziali (Codice Fiscale e password) del nuovo portale studenti Smart_edu. Se non è stata impostata una password, fare accesso al portale studenti con SPID o CIE e impostarla tramite le impostazioni.</span><br>
<p><strong>APP MOBILE </strong> <h1></h1>
<a><img class='googleplay' src="https://en.logodownload.org/wp-content/uploads/2019/06/get-it-on-google-play-badge.png" /></a><br>
<a><img class='appstore' src="https://logos-download.com/wp-content/uploads/2016/06/Download_on_the_App_Store_logo.png" /></a><br><br><br><br>
</p>
     </section>
    <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
      <div class='redfooter'></div>
    </footer>
      </article> 
    
  </body>
</html>
@endsection