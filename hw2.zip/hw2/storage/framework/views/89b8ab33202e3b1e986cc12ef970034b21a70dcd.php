
<!DOCTYPE html>
<html>
<head>
    <title>Profilo</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/gestione.css')); ?>">
</head>
<body>

    <nav></nav>
    <div class='red'></div>

    <div class="container_foto">
        <img class='studium' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_1.png" />  
        <img class='studenti' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_2.jpg" />
    </div>


    <article>
        
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</article>

</body>
</html>
<?php /**PATH C:\Users\giulia\hw2\resources\views/layouts/profiler.blade.php ENDPATH**/ ?>