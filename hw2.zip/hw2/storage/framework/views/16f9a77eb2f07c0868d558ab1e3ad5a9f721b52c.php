

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>
        <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>
        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

          <p><strong>Categoria degli insegnamenti</strong></p><br>

          <li><a class='insegnamenti' href="<?php echo e(route('gestione.agricoltura')); ?>">AGRICOLTURA, ALIMENTAZIONE E AMBIENTE (Di3A)</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.chirurgia')); ?>">CHIRURGIA GENERALE E SPECIALITÀ MEDICO-CHIRURGICHE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.economia')); ?>">ECONOMIA E IMPRESA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.fisica')); ?>">FISICA E ASTRONOMIA "Ettore Majorana"</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.giurisprudenza')); ?>">GIURISPRUDENZA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.dicar')); ?>">INGEGNERIA CIVILE E ARCHITETTURA (DICAR)</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.dieei')); ?>">INGEGNERIA ELETTRICA ELETTRONICA E INFORMATICA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.matematica')); ?>">MATEMATICA E INFORMATICA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.medicina')); ?>">MEDICINA CLINICA E SPERIMENTALE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia')); ?>">SCIENZE BIOLOGICHE, GEOLOGICHE E AMBIENTALI</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.biomedica')); ?>">SCIENZE BIOMEDICHE E BIOTECNOLOGICHE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.chimica')); ?>">SCIENZE CHIMICHE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.farmacia')); ?>">SCIENZE DEL FARMACO E DELLA SALUTE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.formazione')); ?>">SCIENZE DELLA FORMAZIONE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.mediche')); ?>">SCIENZE MEDICHE, CHIRURGICHE E TECNOLOGIE AVANZATE G.F. INGRASSIA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.politica')); ?>">SCIENZE POLITICHE E SOCIALI</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.umanistica')); ?>">SCIENZE UMANISTICHE</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.architettura')); ?>">STRUTTURA DIDATTICA SPECIALE DI ARCHITETTURA, SEDE DECENTRATA DI SIRACUSA</a></li>
          <li><a class='insegnamenti' href="<?php echo e(route('gestione.altascuola')); ?>">Alta Scuola di Formazione degli Insegnanti (ASFI)</a></li>
          
    
        </section>

        <footer><div class='blank'><br> <strong>Amministratore:<a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
        <div class='redfooter'></div>
        </footer>
        
</article>
</body>

</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/profile/gestione.blade.php ENDPATH**/ ?>