

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

          <p>Categorie degli insegnamenti</p><br>

<div>
<?php $__currentLoopData = $insegnamenti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insegnamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('iscrivi')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <strong><input type="hidden" name="insegnamento_id" value="<?php echo e($insegnamento->id); ?>"></strong><br>
    <button class='container2' type="submit"><?php echo e($insegnamento->title); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><br><br>

            <a class='insegnamenti' href="<?php echo e(route('profile.gestione')); ?>">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/gestione/farmacia1.blade.php ENDPATH**/ ?>