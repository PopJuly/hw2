

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Global Politics and Euro-Mediterranean Relations LM-62</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Internazionalizzazione delle relazioni commerciali LM-52</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Management della Pubblica Amministrazione LM-63</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Politiche e Servizi Sociali LM-87</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Scienze dell'amministrazione e dell'organizzazione L-16</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Sociologia delle reti, dell'informazione e dell'innovazione LM-88</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Sociologia e servizio sociale L-39 L-40</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Storia e cultura dei paesi mediterranei</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.politica1')); ?>">Storia, politica e relazioni internazionali</li></a>
            <br>

            <a class='insegnamenti' href="<?php echo e(route('profile.gestione')); ?>">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/gestione/politica.blade.php ENDPATH**/ ?>