

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login with Spotify</title>
</head>
<body>
    <h2>Login with Spotify</h2>
    <a href="<?php echo e(url('/api/login_Spotify')); ?>">Login with Spotify</a>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/loginSpotify.blade.php ENDPATH**/ ?>