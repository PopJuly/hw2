

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Open Library Author Search</title>
</head>
<body>
    <article>
        
    <section>
    <br><p><strong>RICERCA SU OPEN LIBRARY</strong></p><h1></h1><br>
          <ol class='utente'><br><br>
          <p class='dip3'><font>&#9654</font><a href="/">Torna alla homepage</a></p><br>
          </ol>

    <form action="<?php echo e(route('search')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="author" placeholder="Inserire il nome dell'autore" value="<?php echo e(old('author', $author ?? '')); ?>" required><br>
        <button type="submit">Search</button>
    </form>
<div class='container2'>
    <?php if(isset($books) && count($books) > 0): ?>
        <ul>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                   <strong><?php echo e($book['title']); ?> (<?php echo e($book['first_publish_year'] ?? 'Unknown Year'); ?>)</strong>
                    <?php if(isset($book['cover_i'])): ?>
                        <div>
                            <img src="https://covers.openlibrary.org/b/id/<?php echo e($book['cover_i']); ?>-M.jpg" />
                        </div><br>
                    <?php endif; ?>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php elseif(isset($author)): ?>
        <p class='black'>No books found for author "<?php echo e($author); ?>".</p>
    <?php endif; ?>
</div>
</section>

<footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
</article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/search.blade.php ENDPATH**/ ?>