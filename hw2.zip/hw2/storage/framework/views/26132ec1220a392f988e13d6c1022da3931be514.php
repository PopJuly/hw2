

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Conversazione Lingua straniera (inglese) Corso Abilitante da 60 cfu</li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Discipline letterarie e Latino Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Discipline letterarie Istituti II grado Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Discipline letterarie, Latino e Greco Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Filosofia e Scienze Umane Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Filosofia e Storia Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Fisica Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">italiano, Storia, Geografia nella Scuola secondaria di I grado Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua e cultura straniera (Francese) Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua e cultura straniera (Inglese) Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua e cultura straniera (Spagnolo) Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua e cultura straniera (Tedesco) Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua inglese e seconda lingua comunitaria nella Scuola secondaria di I grado (Francese) Corso Abil<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua inglese e seconda lingua comunitaria nella Scuola secondaria di I grado (Inglese) Corso Abil<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Lingua inglese e seconda lingua comunitaria nella Scuola secondaria di I grado (Spagnolo) Corso Abil<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Matematica Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Matematica e Fisica Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Matematica e Scienze Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze e Tecnologie chimiche Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze e Tecnologie informatiche Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze economico-aziendali Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze Matematiche applicate Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze naturali, chimiche e biologiche Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Scienze, Tecnologie e Tecniche agrarie Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Storia dell'Arte Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Tecnologia nella Scuola secondaria di I grado Corso Abilitante da 60 cfu<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.altascuola1')); ?>">Tecnologie elettriche elettroniche Corso Abilitante da 60 cfu<br></li></a>
            <br>

            <a class='insegnamenti' href="<?php echo e(route('profile.gestione')); ?>">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/gestione/altascuola.blade.php ENDPATH**/ ?>