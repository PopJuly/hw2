

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Spotify Album Search</title>
</head>
<body>
<article>
<section>
          <br><p><strong>RICERCA SU SPOTIFY</strong></p><h1></h1><br>
          <ol><br><br>
          <p class='dip3'><font>&#9654</font><a href="/">Torna alla homepage</a></p><br>
          </ol>

          <form action="<?php echo e(route('search')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="query" placeholder="Nome dell'album" required>
        <button type="submit">Search</button>
    </form>
          

    <?php if(isset($album)): ?>
     <section id="music-view">    
        <p class='black'><strong>Name:</strong><br><?php echo e($album['name']); ?></p>
        <p class='black'><strong>Artist:</strong> <?php echo e($album['artists'][0]['name']); ?></p>
        <img id='music-view' src="<?php echo e($album['images'][0]['url']); ?>"><br>
     </section>

        <?php elseif(isset($error)): ?>
        <p><?php echo e($error); ?></p>
    <?php endif; ?>

        <br>
       </section>
        
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
    </article>
    
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/callback.blade.php ENDPATH**/ ?>