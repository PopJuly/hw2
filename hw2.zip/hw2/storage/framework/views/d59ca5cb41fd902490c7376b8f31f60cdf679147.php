

<?php $__env->startSection('content'); ?>

<html>
<head>
    <title>Registrazione utente</title>
</head>
<body>
<article>
<section>
             
    <br><p><strong>ANNO ACCADEMICO </strong> <h1></h1>

    <select name='anno_accademico'>
      <option value = '2023-24'>2023/2024</option>
      <option value = '2022-23'>2022/2023</option>
      <option value = '2021-22'>2021/2022</option>
      <option value = '2020-21'>2020/2021</option>
      <option value = '2019-20'>2019/2020</option>
      <option value = '2018-19'>2018/2019</option>
      <option value = '2017-18'>2017/2018</option>
      <option value = '2016-17'>2016/2017</option>
      <option value = '2015-16'>2015/2016</option>
      <option value = '2014-15'>2014/2015</option>
    </select>

    
      <div class="boxdipartimenti">
        <strong><p class="dipartimenti">DIPARTIMENTI</strong></p><h1></h1>
       <p class="dip2"><a class="dip2" href='agricoltura.php'><font>&#9654</font> AGRICOLTURA, ALIMENTAZIONE E AMBIENTE (Di3A)<br></a></p>
       <p class="dip2"><a class="dip2" href='alta_scuola.php'><font>&#9654</font> Alta Scuola di Formazione degli Insegnanti (ASFI)<br></a></p>       
       <p class="dip2"><a class="dip2" href='chirurgia.php'><font>&#9654</font> CHIRURGIA GENERALE E SPECIALITÀ MEDICO-CHIRURGICHE<br></a></p>
       <p class="dip2"><a class="dip2" href='economia.php'><font>&#9654</font> ECONOMIA E IMPRESA<br></a></p>
       <p class="dip2"><a class="dip2" href='fisica.php'><font>&#9654</font> FISICA E ASTRONOMIA "Ettore Majorana"<br></a></p>
       <p class="dip2"><a class="dip2" href='giurisprudenza.php'><font>&#9654</font> GIURISPRUDENZA<br></a></p>
       <p class="dip2"><a class="dip2" href='dicar.php'><font>&#9654</font> INGEGNERIA CIVILE E ARCHITETTURA (DICAR)<br></a></p>
       <p class="dip2"><a class="dip2" href='dieei.php'><font>&#9654</font> INGEGNERIA ELETTRICA ELETTRONICA E INFORMATICA<br></a></p>
       <p class="dip2"><a class="dip2" href='matematica.php'><font>&#9654</font> MATEMATICA E INFORMATICA<br></a></p>
       <p class="dip2"><a class="dip2" href='medicina.php'><font>&#9654</font> MEDICINA CLINICA E SPERIMENTALE<br></a></p>
       <p class="dip2"><a class="dip2" href='biologia.php'><font>&#9654</font> SCIENZE BIOLOGICHE, GEOLOGICHE E AMBIENTALI<br></a></p>
       <p class="dip2"><a class="dip2" href='biomedica.php'><font>&#9654</font> SCIENZE BIOMEDICHE E BIOTECNOLOGICHE<br></a></p>
       <p class="dip2"><a class="dip2" href='chimica.php'><font>&#9654</font> SCIENZE CHIMICHE<br></a></p>
       <p class="dip2"><a class="dip2" href='farmacia.php'><font>&#9654</font> SCIENZE DEL FARMACO E DELLA SALUTE<br></a></p>
       <p class="dip2"><a class="dip2" href='formazione.php'><font>&#9654</font> SCIENZE DELLA FORMAZIONE<br></a></p>
       <p class="dip2"><a class="dip2" href='mediche.php'><font>&#9654</font> SCIENZE MEDICHE, CHIRURGICHE E TECNOLOGIE AVANZATE G.F. INGRASSIA<br></a></p>
       <p class="dip2"><a class="dip2" href='politica.php'><font>&#9654</font> SCIENZE POLITICHE E SOCIALI<br></a></p>
       <p class="dip2"><a class="dip2" href='umanistica.php'><font>&#9654</font> SCIENZE UMANISTICHE<br></a></p>
       <p class="dip2"><a class="dip2" href='architettura.php'><font>&#9654</font> STRUTTURA DIDATTICA SPECIALE DI ARCHITETTURA, SEDE DECENTRATA DI SIRACUSA<br></a></p>
      
      
      
    </div><br></p><br>

    <form method="POST" action="/register">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">NOME</label><br>
            <input type="text" id="name" name="name" required><br>
        </div><br>
        <div>
            <label for="email">CODICE FISCALE</label><br>
            <input type="text" id="username" name="username" required><br>
        </div><br>
        <div>
            <label for="password">PASSWORD</label><br>
            <input type="password" id="password" name="password" required><br>
        </div><br>
        <div>
            <label for="password_confirmation">CONFERMA PASSWORD</label><br>
            <input type="password" id="password_confirmation" name="password_confirmation" required><br>
        </div><br>
        <div>
            <button type="submit">REGISTRATI</button>
        </div>
    </form><br>

    <p><strong>IN EVIDENZA</strong></p><h1></h1><br><br>
          <ol>  
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_teams_integration.pdf'>Collegamento insegnamenti con Teams </a></p> <br><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti_17-18.pdf'>Attivazione insegnamenti </a></p><br> 
            <p class='dip3'><font>&#9654</font> <a href='https://www.unict.it/'>Portale UniCT </a></p><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studenti.smartedu.unict.it/Login?ReturnUrl=%2f'>Portale Studenti </a></p><br> 
            <p class='dip3'><font>&#9654</font> <a href='https://cas.unict.it/cas/login?service=https%3a%2f%2fdocenti.smartedu.unict.it%2fWorkFlow2011%2fLogon%2fLogon.aspx%3fReturnUrl%3d6a5b0c54-c925-45ff-a7ff-4067ee2f8b0c'>Portale Docenti</a></p><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_studenti.pdf'>Tutorial Studenti </a></p><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti.pdf'>Tutorial Docenti </a></p><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/Studium%20(export%20e%20import%20materiale%20didattico).pdf'>Tutorial export e import materiale didattico </a></p><br><br>
            <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_prenotazioni.pdf'>Tutorial prenotazioni </a></p><br>
          </ol>

          <span class="login"><strong>LOGIN STUDENTI</strong><br>il login degli studenti deve avvenire con le credenziali (Codice Fiscale e password) del nuovo portale 
          studenti Smart_edu. Se non è stata impostata una password, fare accesso al portale studenti 
          con SPID o CIE e impostarla tramite le impostazioni.</span><br>
          <p><strong>APP MOBILE </strong> <h1></h1>
          <a href='https://play.google.com/store/apps/details?id=unict.cea.studium&hl=it&pli=1'><img class='googleplay' src="https://en.logodownload.org/wp-content/uploads/2019/06/get-it-on-google-play-badge.png" /></a><br>
          <a href='https://apps.apple.com/it/app/studium-unict/id1510024640'><img class='appstore' src="https://logos-download.com/wp-content/uploads/2016/06/Download_on_the_App_Store_logo.png" /></a><br><br><br><br>
          </p>
       </section>
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>

</article>

</body>
</html> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\hw2\resources\views/auth/register.blade.php ENDPATH**/ ?>