

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Profilo</title>
</head>
<body>
    <article>
        <section>

        <br><p><strong>Profilo di <?php echo e(Auth::user()->name); ?></strong></p><h1></h1><br>
          <ol class='utente'>
          <p class='dip3'><font>&#9654</font><a href="<?php echo e(route('profile.gestione')); ?>">Gestione degli insegnamenti</a></p>
          <p class='dip3'><font>&#9654</font><a href="/logout">Logout</a></p><br>
          </ol><br>

          <div class='container2'>
          <ul>
        <p><strong>INSEGNAMENTI</strong></p><br>
        <?php $__currentLoopData = $iscrizioni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iscrizione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><p class='insegnamenti'><?php echo e($iscrizione->insegnamento->title); ?></p></li><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul></div>
    <br>

       </section>
        
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
    
</article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views//profile/homeprofile.blade.php ENDPATH**/ ?>