<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    <h1>Benvenuto</h1>
    <form action="<?php echo e(route('iscrizione')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="insegnamento_id">Seleziona Insegnamento:</label>
            <p>Algebra lineare</p>
        </div>
        <button type="submit">Iscriviti</button>
    </form>
    
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <a href="<?php echo e(route('profile')); ?>">Profilo</a>
</body>
</html>

<?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/home.blade.php ENDPATH**/ ?>