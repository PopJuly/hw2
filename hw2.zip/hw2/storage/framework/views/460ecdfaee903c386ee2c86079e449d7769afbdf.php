

<?php $__env->startSection('content'); ?>

<html>
  <head><title>Profilo personale</title></head>
<body>    
<article>
<section>
          <br><p><strong>UTENTE</strong></p><h1></h1><br>
          <ol class='utente'><br><br>
          <p class='dip3'><font>&#9654</font><a href="<?php echo e(route('profile.homeprofile')); ?>">Profilo di <?php echo e(Auth::user()->name); ?></a></p><br>
          <p class='dip3'><font>&#9654</font><a href="<?php echo e(route('profile.gestione')); ?>">Gestione degli insegnamenti</a></p><br>
          <p class='dip3'><font>&#9654</font><a href="/logout">Logout</a></p><br>
          </ol>

          <p class='evidenza'><strong>IN EVIDENZA</strong></p><h1></h1><br>
          <ol><br><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_teams_integration.pdf'>Collegamento insegnamenti con Teams </a></p> <br><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti_17-18.pdf'>Attivazione insegnamenti </a></p><br> 
          <p class='dip3'><font>&#9654</font> <a href='https://www.unict.it/'>Portale UniCT </a></p><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studenti.smartedu.unict.it/Login?ReturnUrl=%2f'>Portale Studenti </a></p><br> 
          <p class='dip3'><font>&#9654</font> <a href='https://cas.unict.it/cas/login?service=https%3a%2f%2fdocenti.smartedu.unict.it%2fWorkFlow2011%2fLogon%2fLogon.aspx%3fReturnUrl%3d6a5b0c54-c925-45ff-a7ff-4067ee2f8b0c'>Portale Docenti</a></p><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_studenti.pdf'>Tutorial Studenti </a></p><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_docenti.pdf'>Tutorial Docenti </a></p><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/Studium%20(export%20e%20import%20materiale%20didattico).pdf'>Tutorial export e import materiale didattico </a></p><br><br>
          <p class='dip3'><font>&#9654</font> <a href='https://studium.unict.it/dokeos/tutorial_prenotazioni.pdf'>Tutorial prenotazioni </a></p><br>
          </ol>

         
          <p><strong>APP MOBILE </strong><h1></h1>
            <a href='https://play.google.com/store/apps/details?id=unict.cea.studium&hl=it&pli=1'><img class='googleplay' src="https://en.logodownload.org/wp-content/uploads/2019/06/get-it-on-google-play-badge.png" /></a><br>
            <a href='https://apps.apple.com/it/app/studium-unict/id1510024640'><img class='appstore' src="https://logos-download.com/wp-content/uploads/2016/06/Download_on_the_App_Store_logo.png" /></a><br><br><br><br>
          </p>
       </section>
        
        <footer><div class='blank'><br> <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
          <div class='redfooter'></div>
        </footer>
    </article>
  </body>
</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/profile/show.blade.php ENDPATH**/ ?>