

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

          <p>Categorie degli insegnamenti</p><br>

            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Biotecnologie agrarie LM-7<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Pianificazione e sostenibilità ambientale del territorio e del paesaggio L-21<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Salvaguardia del terrotorio, dell'ambiente e del paesaggio LM-75<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Scienze e tecnologie agrarie L-25<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Scienze e tecnologie agrarie LM-69<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Scienze e tecnologie alimentari L-26<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Scienze e tecnologie alimentari LM-70<br></li></a>
            <li><a class="insegnamenti" href="<?php echo e(route('gestione.agricoltura1')); ?>">Scienze e tecnologie per la ristorazione e distribuzione degli alimenti mediterranei L-26<br></li></a>
            <br>
            
            <a class='insegnamenti' href="<?php echo e(route('profile.gestione')); ?>">Ritorna agli insegnamenti</a>
    
        </section>
        <footer><div class='blank'><br> <strong>Amministratore:<a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong></div>
        <div class='redfooter'></div>
        </footer>
        </article>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/gestione/agricoltura.blade.php ENDPATH**/ ?>