
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profilo</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/gestione.css')); ?>">
</head>
<body>

    <nav></nav>
    <div class='red'></div>

    <div class="container_foto">
        <img class='studium' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_1.png" />  
        <img class='studenti' src="https://studium.unict.it/dokeos/2024/main/css/dokeos2_unict/studiumbanner2013_2.jpg" />
    </div>


    <article>
        
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</article>

</body>
</html>
<?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/layouts/profiler.blade.php ENDPATH**/ ?>