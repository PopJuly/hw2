

<?php $__env->startSection('content'); ?>
<html>
  <body>
    <article>
      <section>

      <div class='barra_controllo'>
          <a class='barra_controllo' href="<?php echo e(url('/home')); ?>">Home</a>
          <a class='barra_controllo' href="<?php echo e(route('profile.homeprofile')); ?>">Profilo</a>

        </div><br>
          
          <div class='avviso'>
           Nel caso in cui un insegnamento non sia presente, non sia ancora stato attivato dal docente o in caso di
            insegnamenti omonimi/che differiscono solo per il Curriculum, prima di iscriversi chiedere al docente circa 
            l'insegnamento corretto.
          </div><br>

            <p>Categorie degli insegnamenti</p><br>

            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Biologia ambientale LM-6<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Biologia Sperimentale e Applicata LM-79<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Geologia e Geofisica LM-74 LM-74 LM-79<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Geologia e Geofisica LM-74 LM-79<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Geologia e Geofisica LM-79 LM-74 LM-79<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Scienze Ambientali e Naturali L-32<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Scienze biologiche L-13<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Scienze geofisiche LM-79<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Scienze Geologiche L-34<br></li></a>
            <li><a class='insegnamenti' href="<?php echo e(route('gestione.biologia1')); ?>">Sciene Geologiche LM-74<br></li></a>
            <br>

            <a class='insegnamenti' href="<?php echo e(route('profile.gestione')); ?>">Ritorna agli insegnamenti</a>
          
            <br><br>
        </section>
        <footer>
            <div class='blank'><br>
                <strong>Amministratore: <a class='ammin' href='http://www.dieei.unict.it'>Studium.UniCT Amministratore</a></strong>
            </div>
            <div class='redfooter'></div>
        </footer>
    </article> 

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profiler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\giulia\SimpleTaskManager\resources\views/gestione/biologia.blade.php ENDPATH**/ ?>