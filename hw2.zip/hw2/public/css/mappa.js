const PHOTO_LIST = [
    'css/mappa.jpg'
];

