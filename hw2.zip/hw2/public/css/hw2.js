console.log('Hello, user!');

/*Codice per mappa cittadella con modale*/

function createImage(src) {
    const image = document.createElement('img');
    image.src = src;
    return image;
  }
  
  function onThumbnailClick(event) {
    const image = createImage(event.currentTarget.src);
    modalView.appendChild(image);
    modalView.classList.remove('hidden');
  }
  
  function onModalClick() {
    modalView.classList.add('hidden');
    modalView.innerHTML = '';
  }

  const albumView = document.querySelector('#album-view');
  for (let i = 0; i < PHOTO_LIST.length; i++) {
    const photoSrc = PHOTO_LIST[i];
    const image = createImage(photoSrc);
    image.addEventListener('click', onThumbnailClick);
    albumView.appendChild(image);
  }
  
  const modalView = document.querySelector('#modal-view');
  modalView.addEventListener('click', onModalClick);

  /*Codice per tasto indietro*/

  function onClickBack(){
    console.log("Hai premuto indietro!");
    history.back();
  }


  const indietro = document.querySelector('button');
  indietro.addEventListener('click', onClickBack);


  //CODICE per API con openlibrary

  function onJson(json){
      console.log('JSON ricevuto');
      const library = document.querySelector('#library-view');
      library.innerHTLM = ''; //svuotare
  
      let num_results = json.num_found;
      if(num_results > 3) num_results = 3;
      if(num_results == 0){
          console.log("Risultato non trovato");
      }
      
      for(let i=0; i<num_results; i++){
          const doc = json.docs[i];
         // const author = doc.author_name;
          const isbn = doc.isbn[0];
          const cover_url = 'http://covers.openlibrary.org/b/isbn/' + isbn + '-M.jpg';
  
          const book = document.createElement('div');
          book.classList.add('book');
          const img = document.createElement('img');
          img.src = cover_url;
          //const caption = document.createElement('span');
          //caption.textContent = author;
  
          book.appendChild(img);
          //book.appendChild(caption);
          library.appendChild(book);
  
      }
  }
  
  function onResponse(response){
      res = response.json();
      console.log(res);
      return res;
      
  }
  
  function search(event){
      event.preventDefault(); //impedire che la pagina si aggiorni
      const title_input = document.querySelector('#title');
      const title_value = encodeURIComponent(title_input.value);
      console.log('Eseguo ricerca: ' + title_value);
  
      rest_url = 'https://openlibrary.org/search.json?title=' + title_value;
      console.log('URL: ' + rest_url);
  
      fetch(rest_url).then(onResponse).then(onJson);
  }
  
  const form = document.querySelector('form');
  form.addEventListener('submit', search);
  
  
  
  