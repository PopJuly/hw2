<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Insegnamento;

class GestioneController extends Controller
{


    public function agricoltura()
    {
        return view('gestione.agricoltura');
    }

    public function agricoltura1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.agricoltura1', ['insegnamenti' => $insegnamenti]);
    }

    public function chirurgia()
    {
        return view('gestione.chirurgia');
    }

    public function chirurgia1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.chirurgia1', ['insegnamenti' => $insegnamenti]);
    }

    public function economia()
    {
        return view('gestione.economia');
    }

    public function economia1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.economia1', ['insegnamenti' => $insegnamenti]);
    }

    public function fisica()
    {
        return view('gestione.fisica');
    }

    public function fisica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.fisica1', ['insegnamenti' => $insegnamenti]);
    }

    public function giurisprudenza()
    {
        return view('gestione.giurisprudenza');
    }

    public function giurisprudenza1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.giurisprudenza1', ['insegnamenti' => $insegnamenti]);
    }

    public function dicar()
    {
        return view('gestione.dicar');
    }

    public function dicar1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.dicar1', ['insegnamenti' => $insegnamenti]);
    }

    public function dieei()
    {
        return view('gestione.dieei');
    }

    public function dieei1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.dieei1', ['insegnamenti' => $insegnamenti]);
    }

    public function matematica()
    {
        return view('gestione.matematica');
    }

    public function matematica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.matematica1', ['insegnamenti' => $insegnamenti]);
    }

    public function medicina()
    {
        return view('gestione.medicina');
    }

    public function medicina1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.medicina1', ['insegnamenti' => $insegnamenti]);
    }

    public function biologia()
    {
        return view('gestione.biologia');
    }

    public function biologia1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.biologia1', ['insegnamenti' => $insegnamenti]);
    }

    public function biomedica()
    {
        return view('gestione.biomedica');
    }

    public function biomedica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.biomedica1', ['insegnamenti' => $insegnamenti]);
    }

    public function chimica()
    {
        return view('gestione.chimica');
    }

    public function chimica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.chimica1', ['insegnamenti' => $insegnamenti]);
    }

    public function farmacia()
    {
        return view('gestione.farmacia');
    }

    public function farmacia1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.farmacia1', ['insegnamenti' => $insegnamenti]);
    }

    public function formazione()
    {
        return view('gestione.formazione');
    }

    public function formazione1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.formazione1', ['insegnamenti' => $insegnamenti]);
    }

    public function mediche()
    {
        return view('gestione.mediche');
    }

    public function mediche1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.mediche1', ['insegnamenti' => $insegnamenti]);
    }

    public function politica()
    {
        return view('gestione.politica');
    }

    
    public function politica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.politica1', ['insegnamenti' => $insegnamenti]);
    }

    public function umanistica()
    {
        return view('gestione.umanistica');
    }

    public function umanistica1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.umanistica1', ['insegnamenti' => $insegnamenti]);
    }
    
    public function architettura()
    {
        return view('gestione.architettura');
    }

    public function architettura1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.architettura1', ['insegnamenti' => $insegnamenti]);
    }
    
    public function altascuola()
    {
        return view('gestione.altascuola');
    }

    public function altascuola1()
    {
        $insegnamenti = Insegnamento::all();
        return view('gestione.altascuola1', ['insegnamenti' => $insegnamenti]);
    }
}
