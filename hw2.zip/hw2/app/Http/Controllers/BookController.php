<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BookController extends Controller
{
    public function index()
    {
        return view('searchbook');
    }

    public function searchbook(Request $request)
    {
        $author = $request->input('author');
        $limit = 5; 

        $response = Http::get('https://openlibrary.org/search.json', [
            'author' => $author,
            'limit' => $limit,
        ]);

        $data = $response->json();

        if (isset($data['docs'])) {
            $books = array_slice($data['docs'], 0, $limit);
        } else {
            $books = [];
        }
        

        return view('searchbook', ['books' => $books, 'author' => $author]);
    }
}


