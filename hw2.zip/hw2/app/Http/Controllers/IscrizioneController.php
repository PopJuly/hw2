<?php

namespace App\Http\Controllers;

use App\Models\Iscrizione;
use App\Models\Insegnamento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class IscrizioneController extends Controller
{
    

    public function iscrizione(Request $request)
    {
            $request->validate([
                'insegnamento_id' => 'required|exists:insegnamenti,id',
            ]);
    
            $iscrizione = Iscrizione::firstOrCreate([
                'studente_id' => Auth::id(),
                'insegnamento_id' => $request->insegnamento_id,
            ]);
    
            return redirect()->route('profile.homeprofile')->with('success', 'Iscrizione effettuata con successo!');
        }

    
}


