<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InsegnamentiController extends Controller
{
    public function agricoltura()
    {
        return view('insegnamenti.agricoltura');
    }

    public function agricoltura1()
    {
        return view('insegnamenti.agricoltura1');
    }

    public function agricoltura2()
    {
        return view('insegnamenti.agricoltura2');
    }

    public function agricoltura3()
    {
        return view('insegnamenti.agricoltura3');
    }

    public function agricoltura4()
    {
        return view('insegnamenti.agricoltura4');
    }

    public function agricoltura5()
    {
        return view('insegnamenti.agricoltura5');
    }

    public function agricoltura6()
    {
        return view('insegnamenti.agricoltura6');
    }

    public function agricoltura7()
    {
        return view('insegnamenti.agricoltura7');
    }

    public function agricoltura8()
    {
        return view('insegnamenti.agricoltura8');
    }

    public function chirurgia()
    {
        return view('insegnamenti.chirurgia');
    }

    public function chirurgia1()
    {
        return view('insegnamenti.chirurgia1');
    }

    public function chirurgia2()
    {
        return view('insegnamenti.chirurgia2');
    }

    public function chirurgia3()
    {
        return view('insegnamenti.chirurgia3');
    }

    public function chirurgia4()
    {
        return view('insegnamenti.chirurgia4');
    }

    public function chirurgia5()
    {
        return view('insegnamenti.chirurgia5');
    }

    public function economia()
    {
        return view('insegnamenti.economia');
    }

    public function economia1()
    {
        return view('insegnamenti.economia1');
    }

    public function economia2()
    {
        return view('insegnamenti.economia2');
    }

    public function economia3()
    {
        return view('insegnamenti.economia3');
    }

    public function economia4()
    {
        return view('insegnamenti.economia4');
    }

    public function economia5()
    {
        return view('insegnamenti.economia5');
    }

    public function economia6()
    {
        return view('insegnamenti.economia6');
    }

    public function economia7()
    {
        return view('insegnamenti.economia7');
    }

    public function fisica()
    {
        return view('insegnamenti.fisica');
    }

    public function fisica1()
    {
        return view('insegnamenti.fisica1');
    }

    public function fisica2()
    {
        return view('insegnamenti.fisica2');
    }

    public function giurisprudenza()
    {
        return view('insegnamenti.giurisprudenza');
    }

    public function giurisprudenza1()
    {
        return view('insegnamenti.giurisprudenza1');
    }

    public function dicar()
    {
        return view('insegnamenti.dicar');
    }

    public function dicar1()
    {
        return view('insegnamenti.dicar1');
    }

    public function dicar2()
    {
        return view('insegnamenti.dicar2');
    }

    public function dicar3()
    {
        return view('insegnamenti.dicar3');
    }

    public function dicar4()
    {
        return view('insegnamenti.dicar4');
    }

    public function dicar5()
    {
        return view('insegnamenti.dicar5');
    }

    public function dicar6()
    {
        return view('insegnamenti.dicar6');
    }

    public function dicar7()
    {
        return view('insegnamenti.dicar7');
    }

    public function dicar8()
    {
        return view('insegnamenti.dicar8');
    }

    public function dieei()
    {
        return view('insegnamenti.dieei');
    }

    public function dieei1()
    {
        return view('insegnamenti.dieei1');
    }
    
    public function dieei2()
    {
        return view('insegnamenti.dieei2');
    }
    
    public function dieei3()
    {
        return view('insegnamenti.dieei3');
    }
    
    public function dieei4()
    {
        return view('insegnamenti.dieei4');
    }
    
    public function dieei5()
    {
        return view('insegnamenti.dieei5');
    }
    
    public function dieei6()
    {
        return view('insegnamenti.dieei6');
    }
    
    public function dieei7()
    {
        return view('insegnamenti.dieei7');
    }
    
    public function dieei8()
    {
        return view('insegnamenti.dieei8');
    }

    public function matematica()
    {
        return view('insegnamenti.matematica');
    }

    public function matematica1()
    {
        return view('insegnamenti.matematica1');
    }

    public function matematica2()
    {
        return view('insegnamenti.matematica2');
    }
    
    public function matematica3()
    {
        return view('insegnamenti.matematica3');
    }
    
    public function matematica4()
    {
        return view('insegnamenti.matematica4');
    }

    public function medicina()
    {
        return view('insegnamenti.medicina');
    }

    public function medicina1()
    {
        return view('insegnamenti.medicina1');
    }

    public function medicina2()
    {
        return view('insegnamenti.medicina2');
    }

    public function medicina3()
    {
        return view('insegnamenti.medicina3');
    }

    public function medicina4()
    {
        return view('insegnamenti.medicina4');
    }
    
    public function medicina5()
    {
        return view('insegnamenti.medicina5');
    }


    public function biologia()
    {
        return view('insegnamenti.biologia');
    }

    public function biologia1()
    {
        return view('insegnamenti.biologia1');
    }

    public function biologia2()
    {
        return view('insegnamenti.biologia2');
    }

    public function biologia3()
    {
        return view('insegnamenti.biologia3');
    }

    public function biologia4()
    {
        return view('insegnamenti.biologia4');
    }

    public function biologia5()
    {
        return view('insegnamenti.biologia5');
    }

    public function biologia6()
    {
        return view('insegnamenti.biologia6');
    }

    public function biologia7()
    {
        return view('insegnamenti.biologia7');
    }

    public function biologia8()
    {
        return view('insegnamenti.biologia8');
    }

    public function biologia9()
    {
        return view('insegnamenti.biologia9');
    }

    public function biologia10()
    {
        return view('insegnamenti.biologia10');
    }

    public function biomedica()
    {
        return view('insegnamenti.biomedica');
    }

    public function biomedica1()
    {
        return view('insegnamenti.biomedica1');
    }

    public function biomedica2()
    {
        return view('insegnamenti.biomedica2');
    }

    public function biomedica3()
    {
        return view('insegnamenti.biomedica3');
    }

    public function biomedica4()
    {
        return view('insegnamenti.biomedica4');
    }

    public function biomedica5()
    {
        return view('insegnamenti.biomedica5');
    }

    public function biomedica6()
    {
        return view('insegnamenti.biomedica6');
    }

    public function biomedica7()
    {
        return view('insegnamenti.biomedica7');
    }

    public function biomedica8()
    {
        return view('insegnamenti.biomedica8');
    }

    public function chimica()
    {
        return view('insegnamenti.chimica');
    }

    public function chimica1()
    {
        return view('insegnamenti.chimica1');
    }

    public function chimica2()
    {
        return view('insegnamenti.chimica2');
    }

    public function chimica3()
    {
        return view('insegnamenti.chimica3');
    }

    public function farmacia()
    {
        return view('insegnamenti.farmacia');
    }

    public function farmacia1()
    {
        return view('insegnamenti.farmacia1');
    }

    public function farmacia2()
    {
        return view('insegnamenti.farmacia2');
    }

    public function farmacia3()
    {
        return view('insegnamenti.farmacia3');
    }

    public function formazione()
    {
        return view('insegnamenti.formazione');
    }

    public function formazione1()
    {
        return view('insegnamenti.formazione1');
    }

    public function formazione2()
    {
        return view('insegnamenti.formazione2');
    }

    public function formazione3()
    {
        return view('insegnamenti.formazione3');
    }

    public function formazione4()
    {
        return view('insegnamenti.formazione4');
    }

    public function formazione5()
    {
        return view('insegnamenti.formazione5');
    }

    public function mediche()
    {
        return view('insegnamenti.mediche');
    }

    public function mediche1()
    {
        return view('insegnamenti.mediche1');
    }

    public function mediche2()
    {
        return view('insegnamenti.mediche2');
    }

    public function mediche3()
    {
        return view('insegnamenti.mediche3');
    }

    public function mediche4()
    {
        return view('insegnamenti.mediche4');
    }

    public function mediche5()
    {
        return view('insegnamenti.mediche5');
    }

    public function politica()
    {
        return view('insegnamenti.politica');
    }
    
    public function politica1()
    {
        return view('insegnamenti.politica1');
    }

    public function umanistica()
    {
        return view('insegnamenti.umanistica');
    }

    public function umanistica1()
    {
        return view('insegnamenti.umanistica1');
    }
    
    public function architettura()
    {
        return view('insegnamenti.architettura');
    }

    public function architettura1()
    {
        return view('insegnamenti.architettura1');
    }
    
    public function altascuola()
    {
        return view('insegnamenti.altascuola');
    }

    public function altascuola1()
    {
        return view('insegnamenti.altascuola1');
    }
}
