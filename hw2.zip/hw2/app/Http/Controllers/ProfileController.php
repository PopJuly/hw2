<?php

namespace App\Http\Controllers;

use App\Models\Iscrizione;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function showProfile()
    {
        return view('profile.show');
    }

    public function editProfile()
    {
        return view('profile.gestione');
    }

    public function logout()
    {
        return view('profile.logout');
    }

    public function Profile()
    {
        $iscrizioni = Iscrizione::where('studente_id', Auth::id())->with('insegnamento')->get();

        return view('/profile/homeprofile', compact('iscrizioni'));
    }

}
