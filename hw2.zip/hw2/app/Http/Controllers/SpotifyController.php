<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class SpotifyController extends Controller
{
    private $clientId;
    private $clientSecret;
    private $redirectUri;

    public function __construct()
    {
        $this->clientId = env('SPOTIFY_CLIENT_ID');
        $this->clientSecret = env('SPOTIFY_CLIENT_SECRET');
        $this->redirectUri = env('SPOTIFY_REDIRECT_URI');
    }

    public function callback(Request $request)
    {
        return view('callback');
    }

    public function search(Request $request)
    {
        $token = $this->getAccessToken();
        $query = $request->input('query');

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->get('https://api.spotify.com/v1/search', [
            'q' => $query,
            'type' => 'album',
            'limit' => 1,
        ]);

        $data = $response->json();

        if (isset($data['albums']['items'][0])) {
            $album = $data['albums']['items'][0];
            return view('callback', ['album' => $album]);
        } else {
            return view('callback', ['album' => null, 'error' => 'Nessun album trovato.']);
        }
    }

    private function getAccessToken()
    {
        $response = Http::withHeaders([
            'Authorization' => 'Basic ' . base64_encode($this->clientId . ':' . $this->clientSecret),
        ])->asForm()->post('https://accounts.spotify.com/api/token', [
            'grant_type' => 'client_credentials',
        ]);

        $data = $response->json();

        return $data['access_token'];
    }
}
