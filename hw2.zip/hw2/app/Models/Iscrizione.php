<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Iscrizione extends Model
{
    protected $table = 'iscrizioni'; 
    protected $fillable = ['studente_id', 'insegnamento_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function insegnamento()
    {
        return $this->belongsTo(Insegnamento::class);
    }

    public function studente()
    {
        return $this->belongsTo(User::class, 'studente_id');
    }
}




