<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Insegnamento extends Model
{
    protected $table = 'insegnamenti';

    // Se necessario, specifica i campi fillable o guarded
    protected $fillable = ['nome'];
}



